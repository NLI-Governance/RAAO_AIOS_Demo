import streamlit as st
import json
from datetime import datetime

# Paths (adjust as needed)
fallback_path = "../data/policies/lookup_aids/rag_fallback_topics.json"
log_path = "../data/policies/lookup_aids/policy_query_log.json"

st.title("📘 AI Policy Assistant with Citation")
query = st.text_input("Ask a policy question:")

if query:
    norm_query = query.lower().strip()
    with open(fallback_path, "r", encoding="utf-8") as f:
        fallback_data = json.load(f)

    match = fallback_data.get(norm_query)

    if match:
        st.success(match.get("note", "Policy match found."))
        st.markdown(f"**📘 Source:** `{match['document']}`")
        st.markdown(f"**📎 Section:** {match['section']}")

        log_entry = {
            "query": query,
            "method": "Fallback",
            "document": match["document"],
            "section": match["section"],
            "timestamp": datetime.now().isoformat()
        }

        try:
            with open(log_path, "r", encoding="utf-8") as lf:
                log_data = json.load(lf)
        except FileNotFoundError:
            log_data = []

        log_data.append(log_entry)
        with open(log_path, "w", encoding="utf-8") as lf:
            json.dump(log_data, lf, indent=2)

    else:
        st.warning("No direct match. Please rephrase or contact HR.")
