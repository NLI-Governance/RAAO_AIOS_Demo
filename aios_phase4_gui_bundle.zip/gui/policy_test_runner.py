import json
from datetime import datetime
from pathlib import Path

# Paths to loaded lookup aids
alias_path = Path("../data/policies/lookup_aids/keyword_alias_dictionary.json")
synonym_path = Path("../data/policies/lookup_aids/synonym_context_expander.json")
fallback_path = Path("../data/policies/lookup_aids/rag_fallback_topics.json")
log_path = Path("../data/policies/lookup_aids/policy_query_log.json")

# Load lookup data
alias_dict = json.load(open(alias_path))
synonym_dict = json.load(open(synonym_path))
fallback_dict = json.load(open(fallback_path))

# Test queries
queries = [
    "Can I wear jeans on Friday?",
    "Do we have a grievance policy?",
    "Are pets allowed in the office?",
    "How do I report unsafe conditions?",
    "Can I request FMLA leave?",
    "Is there an employee referral program?",
    "What is the dress code for remote workers?",
    "Are interns eligible for paid holidays?",
    "Where can I find the staff handbook?",
    "What happens if I lose my badge?"
]

# Normalize helper
def normalize(text):
    return text.lower().strip().replace("?", "")

# Process
results = []
for query in queries:
    norm = normalize(query)
    match_type = []

    if any(alias in norm for alias in alias_dict):
        match_type.append("Alias")
    if any(syn in norm for syn in synonym_dict):
        match_type.append("Synonym")
    if norm in fallback_dict:
        match_type.append("Fallback")

    if not match_type:
        match_type = ["GPT"]

    results.append({
        "query": query,
        "method": ", ".join(match_type),
        "timestamp": datetime.now().isoformat()
    })

# Write to log
if log_path.exists():
    existing = json.load(open(log_path))
else:
    existing = []

existing.extend(results)
with open(log_path, "w", encoding="utf-8") as f:
    json.dump(existing, f, indent=2)

# Display summary
print("\nBenchmark Test Runner Results:")
for r in results:
    print(f"[{r['method']}] → {r['query']}")
