# navigation_menu_gui.py
# Main menu interface for AIOS – organized by department/module

import streamlit as st

st.set_page_config(page_title="AIOS Navigation Menu", layout="centered")
st.image("logo.png", width=120)
st.title("🧭 AIOS System Navigation")

st.markdown("Welcome to the Adaptive Integrated Operations System. Select a module below to begin:")

st.divider()

st.subheader("📁 HR & Employee Operations")

st.markdown("- [Employee Application Form](employee_application_gui.py)")
st.markdown("- [Benefits Enrollment](benefits_enrollment_gui.py)")
st.markdown("- [Training Tracker](training_tracker_gui.py)")
st.markdown("- [Disciplinary Action Log](disciplinary_actions_gui.py)")

st.divider()

st.subheader("💼 Payroll & Grant Accounting")

st.markdown("- [Vendor Onboarding](vendor_onboarding_gui.py)")
st.markdown("- [Customer Onboarding](customer_onboarding_gui.py)")
st.markdown("- [Grant Code Manager](grant_funding_code_manager_gui.py)")
st.markdown("- [Timecode Entry (Payroll)](payroll_timecode_entry_gui.py)")

st.divider()

st.subheader("🧠 Internal AI Assistant")

st.markdown("- [AI Helper](ai_helper_global_gui.py)")

st.markdown("---")
st.markdown("© 2025 Rising Against All Odds | All modules shown reflect Phase 1 deployment")
